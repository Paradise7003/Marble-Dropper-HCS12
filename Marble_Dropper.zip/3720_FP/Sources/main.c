#include <hidef.h>        // common defines and macros
#include "derivative.h"    // device-specific definitions

// LCD pins: PK5�PK2 = D7�D4, PK1 = EN, PK0 = RS
#define LCD_DATA        PORTK
#define LCD_CTRL        PORTK
#define RS              0x01
#define EN              0x02

// IR channels and threshold
#define IR_THRESHOLD    100
#define IR1_CH           5
#define IR2_CH           6

// Water sensor on AN7
#define WATER_CH         7
#define WATER_HIGH       100
#define WATER_LOW        110

// Container geometry
#define AREA_CM2         50
#define H_MM_PER_COUNT   1

void COMWRT4(unsigned char);
void DATWRT4(unsigned char);
void MSDelay(unsigned int);
void LCD_ShowTimeSec(unsigned int, unsigned int);
void LCD_ShowVolume(unsigned int);
void ADC_Init(void);
unsigned char ADC_ReadCh(unsigned char);

void main(void)
{
    unsigned char sensor, w;
    unsigned int  before, after;
    unsigned int  elapsed_ms, last_elapsed_ms;
    unsigned int  delta, volume_ml, last_volume_ml;
    unsigned int  marbles, last_marbles;
    unsigned int  i;

    // Port setup
    DDRB   = 0xFF;     // stepper coils
    DDRP  |= 0x03;     // H-bridge enables
    PTP    = 0x03;     // enable driver
    DDRK   = 0xFF;     // LCD

    // LCD init
    COMWRT4(0x33); MSDelay(1);
    COMWRT4(0x32); MSDelay(1);
    COMWRT4(0x28); MSDelay(1);
    COMWRT4(0x06); MSDelay(1);
    COMWRT4(0x0C); MSDelay(1);
    COMWRT4(0x01); MSDelay(2);

    // ADC init
    ADC_Init();

    // initial spin until IR2 trips
    for (i = 0; i < 256; i++) {
        PORTB = 0x03; MSDelay(5);
        PORTB = 0x06; MSDelay(5);
        PORTB = 0x0C; MSDelay(5);
        PORTB = 0x09; MSDelay(5);
    }
    MSDelay(50);
    do {
        sensor = ADC_ReadCh(IR2_CH);
        MSDelay(1);
    } while (sensor < IR_THRESHOLD);

    last_elapsed_ms = 0;
    last_volume_ml  = 0;
    marbles         = 0;
    last_marbles    = 0;
    LCD_ShowTimeSec(0,0);
    LCD_ShowVolume(0);

    // Main loop
    for (;;)
    {
        // water warning
        w = ADC_ReadCh(WATER_CH);
        if (w <= WATER_HIGH) {
            do {
                COMWRT4(0x01); MSDelay(2);
                COMWRT4(0x80);
                  DATWRT4(' '); DATWRT4(' '); DATWRT4(' ');
                  DATWRT4('W'); DATWRT4('A'); DATWRT4('T');
                  DATWRT4('E'); DATWRT4('R'); DATWRT4('!');
                  DATWRT4('!'); DATWRT4('!'); DATWRT4(' ');
                COMWRT4(0xC0);
                  DATWRT4(' '); DATWRT4(' '); DATWRT4(' ');
                  DATWRT4('W'); DATWRT4('A'); DATWRT4('T');
                  DATWRT4('E'); DATWRT4('R'); DATWRT4('!');
                  DATWRT4('!'); DATWRT4('!'); DATWRT4(' ');
                MSDelay(200);
                w = ADC_ReadCh(WATER_CH);
            } while (w >= WATER_LOW);
            COMWRT4(0x01); MSDelay(2);
            LCD_ShowTimeSec(last_elapsed_ms, last_marbles);
            LCD_ShowVolume(last_volume_ml);
        }

        // before water reading and IR1 start
        before     = ADC_ReadCh(WATER_CH);
        elapsed_ms = 0;
        do {
            MSDelay(1);
            elapsed_ms++;
            sensor = ADC_ReadCh(IR1_CH);
        } while (sensor >= IR_THRESHOLD);

        marbles++;

        // wait IR1 clear
        do {
            sensor = ADC_ReadCh(IR1_CH);
            MSDelay(1);
        } while (sensor < IR_THRESHOLD);

        // IR2 stop and after water reading
        do {
            MSDelay(1);
            elapsed_ms++;
            sensor = ADC_ReadCh(IR2_CH);
        } while (sensor >= IR_THRESHOLD);
        after = ADC_ReadCh(WATER_CH);

        // compute volume
        if (before >= after)
            delta = before - after;
        else
            delta = 0;
        volume_ml = (delta * H_MM_PER_COUNT * AREA_CM2) / 10;

        // update display
        LCD_ShowTimeSec(elapsed_ms, marbles);
        LCD_ShowVolume(volume_ml);
        last_elapsed_ms = elapsed_ms;
        last_volume_ml  = volume_ml;
        last_marbles    = marbles;

        // spin tray
        for (i = 0; i < 256; i++) {
            PORTB = 0x03; MSDelay(5);
            PORTB = 0x06; MSDelay(5);
            PORTB = 0x0C; MSDelay(5);
            PORTB = 0x09; MSDelay(5);
        }
        MSDelay(50);

        // wait IR2 clear
        do {
            sensor = ADC_ReadCh(IR2_CH);
            MSDelay(1);
        } while (sensor < IR_THRESHOLD);
    }
}
//LCD constraints
void COMWRT4(unsigned char cmd)
{
    unsigned char hi, lo;
    hi = (cmd & 0xF0) >> 2;
    lo = (cmd & 0x0F) << 2;
    LCD_DATA = (LCD_DATA & ~0x3C) | hi;
    LCD_CTRL &= ~RS; MSDelay(1);
    LCD_CTRL |=  EN; MSDelay(2);
    LCD_CTRL &= ~EN; MSDelay(2);
    LCD_DATA = (LCD_DATA & ~0x3C) | lo;
    LCD_CTRL |=  EN; MSDelay(2);
    LCD_CTRL &= ~EN; MSDelay(2);
}

void DATWRT4(unsigned char d)
{
    unsigned char hi, lo;
    hi = (d & 0xF0) >> 2;
    lo = (d & 0x0F) << 2;
    LCD_DATA = (LCD_DATA & ~0x3C) | hi;
    LCD_CTRL |= RS; MSDelay(1);
    LCD_CTRL |= EN; MSDelay(2);
    LCD_CTRL &= ~EN; MSDelay(2);
    LCD_DATA = (LCD_DATA & ~0x3C) | lo;
    LCD_CTRL |= EN; MSDelay(2);
    LCD_CTRL &= ~EN; MSDelay(2);
}

void LCD_ShowTimeSec(unsigned int ms, unsigned int count)
{
    unsigned int secs = ms/1000, t = secs;
    unsigned char idx = 0;
    char buf[3];

    COMWRT4(0x80); MSDelay(1);
    DATWRT4('T'); DATWRT4('i'); DATWRT4('m');
    DATWRT4('e'); DATWRT4(':'); DATWRT4(' ');
    if (secs == 0) {
        DATWRT4('0');
    } else {
        while (t && idx < sizeof(buf)) {
            buf[idx++] = (char)('0' + (t % 10));
            t /= 10;
        }
        while (idx) DATWRT4(buf[--idx]);
    }
    DATWRT4('s'); DATWRT4(' ');

    DATWRT4('M'); DATWRT4(':');
    t = count; idx = 0;
    if (count == 0) {
        DATWRT4('0');
    } else {
        while (t && idx < sizeof(buf)) {
            buf[idx++] = (char)('0' + (t % 10));
            t /= 10;
        }
        while (idx) DATWRT4(buf[--idx]);
    }
    DATWRT4(' ');
}

void LCD_ShowVolume(unsigned int vol)
{
    unsigned int t = vol;
    unsigned char idx = 0;
    char buf[4];

    COMWRT4(0xC0); MSDelay(1);
    DATWRT4('V'); DATWRT4('o'); DATWRT4('l');
    DATWRT4(':'); DATWRT4(' ');
    if (vol == 0) {
        DATWRT4('0');
    } else {
        while (t && idx < sizeof(buf)) {
            buf[idx++] = (char)('0' + (t % 10));
            t /= 10;
        }
        while (idx) DATWRT4(buf[--idx]);
    }
    DATWRT4('m'); DATWRT4('L');
    DATWRT4(' ');
}
//delay functions
void MSDelay(unsigned int ms)
{
    unsigned int a, b;
    for (a = 0; a < ms; a++)
        for (b = 0; b < 4000; b++) { }
}
//port initiations 
void ADC_Init(void)
{
    ATD0CTL2 = 0x80; MSDelay(2);
    ATD0CTL3 = 0x08;
    ATD0CTL4 = 0xEB;
}

unsigned char ADC_ReadCh(unsigned char ch)
{
    ATD0CTL5 = 0x80 | (ch & 0x07);
    while (!(ATD0STAT0 & 0x80)) { }
    return ATD0DR0L;
}
